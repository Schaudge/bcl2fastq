#ifndef MATCH_H_
#define MATCH_H_

unsigned int longest_match  (deflate_state *s, IPos cur_match);

#endif /* MATCH_H_ */
